from app import AttendanceApp

if __name__ == "__main__":
    AttendanceApp().run()
